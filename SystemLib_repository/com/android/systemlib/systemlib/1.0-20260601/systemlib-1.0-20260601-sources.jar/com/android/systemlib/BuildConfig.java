/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.android.systemlib;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.android.systemlib";
  public static final String BUILD_TYPE = "release";
}
